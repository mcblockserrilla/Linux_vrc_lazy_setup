#!/bin/bash

set -e

# ---------------------
# Paths and filenames
# ---------------------
UNITY_FLATPAK_ID="com.unity.UnityHub"
UNITY_FLATPAK_LIC="$HOME/.var/app/$UNITY_FLATPAK_ID/data/unity3d/Unity/Unity_lic.ulf"
UNITY_FLATPAK_CFG="$HOME/.var/app/$UNITY_FLATPAK_ID/config/unityhub"
UNITY_APPIMAGE_LIC="$HOME/.local/share/unity3d/Unity/Unity_lic.ulf"
UNITY_APPIMAGE_CFG="$HOME/.config/unityhub"
ALCOM_APPIMAGE="$PWD/ALCOM.AppImage"
WAIT_TIMEOUT=60

echo "===[ ALCOM + Unity Launcher ]==="

# ---------------------
# 1. Ensure flatpak is installed
# ---------------------
if ! command -v flatpak &> /dev/null; then
    echo "[!] Flatpak not found. Installing..."
    if command -v pacman &> /dev/null; then
        sudo pacman -S --noconfirm flatpak
        sudo systemctl enable --now flatpak.socket
        sudo ln -sf /var/lib/flatpak/exports/bin /snap 2>/dev/null || true
    else
        echo "[!] Unsupported distro. Please install Flatpak manually."
        exit 1
    fi
fi

# ---------------------
# 2. Ensure Unity Hub Flatpak is installed
# ---------------------
if ! flatpak list | grep -q "$UNITY_FLATPAK_ID"; then
    echo "[+] Installing Unity Hub Flatpak..."
    flatpak install -y flathub $UNITY_FLATPAK_ID
fi

# ---------------------
# 3. Launch Unity Hub
# ---------------------
echo "[+] Launching Unity Hub (please sign in if you haven't)..."
flatpak run "$UNITY_FLATPAK_ID" &

# ---------------------
# 4. Wait for license to appear
# ---------------------
echo "[…] Waiting for Unity license file..."
TIME_WAITED=0
while [ ! -f "$UNITY_FLATPAK_LIC" ]; do
    sleep 2
    TIME_WAITED=$((TIME_WAITED + 2))
    if [ $TIME_WAITED -ge $WAIT_TIMEOUT ]; then
        echo "[!] Timeout: Unity license file not found after $WAIT_TIMEOUT seconds."
        echo "    Please make sure you're signed in to Unity Hub and licensed."
        exit 1
    fi
done
echo "[✓] Unity license detected."

# ---------------------
# 5. Sync license and config
# ---------------------
echo "[+] Syncing license and Unity config..."

mkdir -p "$(dirname "$UNITY_APPIMAGE_LIC")"
mkdir -p "$(dirname "$UNITY_APPIMAGE_CFG")"

cp -f "$UNITY_FLATPAK_LIC" "$UNITY_APPIMAGE_LIC"
rm -rf "$UNITY_APPIMAGE_CFG"
cp -r "$UNITY_FLATPAK_CFG" "$UNITY_APPIMAGE_CFG"

echo "[✓] License and config copied."

# ---------------------
# 6. Launch ALCOM
# ---------------------
echo "[+] Launching ALCOM..."
chmod +x "$ALCOM_APPIMAGE"
"$ALCOM_APPIMAGE"
