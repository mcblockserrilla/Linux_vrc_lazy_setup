#!/bin/bash
set -e

PROGRAMS_DIR="$HOME/Program Files"
UNITY_DIR="$PROGRAMS_DIR/unity"

mkdir -p "$PROGRAMS_DIR"

function install_if_missing() {
  local cmd="$1"
  local pkg="$2"
  if ! command -v "$cmd" &>/dev/null; then
    echo "📦 Installing $pkg..."
    sudo pacman -S --noconfirm "$pkg"
  else
    echo "✅ $pkg already installed."
  fi
}

function install_yay() {
  if ! command -v yay &>/dev/null; then
    echo "📥 yay not found. Installing yay..."
    sudo pacman -S --noconfirm --needed git base-devel
    tmpdir=$(mktemp -d)
    git clone https://aur.archlinux.org/yay.git "$tmpdir/yay"
    pushd "$tmpdir/yay"
    makepkg -si --noconfirm
    popd
    rm -rf "$tmpdir"
    echo "✅ yay installed successfully."
  else
    echo "✅ yay already installed."
  fi
}

function install_snapd() {
  if ! command -v snap &>/dev/null; then
    echo "📥 Installing snapd..."
    sudo pacman -S --noconfirm snapd
    sudo systemctl enable --now snapd.socket
    sudo ln -s /var/lib/snapd/snap /snap || true
    sudo snap install snap-store
  else
    echo "✅ snapd already installed."
  fi
}

function install_snap_app() {
  local appid="$1"
  if ! snap list | grep -q "$appid"; then
    echo "📥 Installing $appid via Snap..."
    sudo snap install "$appid"
  else
    echo "✅ $appid already installed via Snap."
  fi
}

function install_unity_hub() {
  mkdir -p "$UNITY_DIR"
  if ! flatpak list | grep -q "com.unity.UnityHub"; then
    echo "📥 Installing Unity Hub via Flatpak..."
    flatpak install -y flathub com.unity.UnityHub
  else
    echo "✅ Unity Hub already installed via Flatpak."
  fi
}

function open_alcom_download_page() {
  echo "🌐 Opening ALCOM download page in browser..."
  xdg-open "https://vrc-get.anatawa12.com/en/alcom/" &>/dev/null || \
    echo "❌ Could not open browser. Please visit manually: https://vrc-get.anatawa12.com/en/alcom/"
}

# Start setup
install_yay

sudo pacman -Syu --noconfirm

# Core tools
install_if_missing python python
install_if_missing pip python-pip
install_if_missing steam steam
install_if_missing git git
install_if_missing blender blender
install_if_missing gimp gimp
install_if_missing xdotool xdotool
install_if_missing wmctrl wmctrl
install_if_missing xwininfo xorg-xwininfo
install_if_missing jq jq

# Audio tools
install_if_missing pavucontrol pavucontrol
install_if_missing easyeffects easyeffects
install_if_missing helvum helvum
install_if_missing pipewire pipewire
install_if_missing pipewire-pulse pipewire-pulse

# Snap setup
install_snapd

# Discord via Snap
install_snap_app discord

# ALVR (AUR)
if command -v yay &>/dev/null && yay -Si alvr &>/dev/null; then
  yay -Sy --noconfirm alvr
else
  echo "⚠️ ALVR not found in AUR or yay unavailable."
fi

# Unity
install_unity_hub

# ALCOM (manual install)
open_alcom_download_page

# WiVRn - VR streaming
echo "📥 Installing WiVRn via Flatpak..."
flatpak install -y flathub io.github.wivrn.wivrn || echo "⚠️ Failed to install WiVRn via Flatpak."

# Envision - VR GUI config tool
if yay -Si envision-xr-git &>/dev/null; then
  yay -S --noconfirm envision-xr-git
else
  echo "⚠️ Envision not found in AUR or yay unavailable."
fi

# Avahi daemon for mDNS / VR discovery
echo "🔧 Enabling Avahi daemon..."
sudo systemctl enable --now avahi-daemon

# Done
cat <<EOF

✅ Setup complete!

📦 Installed tools:
- Unity Hub (Flatpak):      flatpak run com.unity.UnityHub
- ALVR (AUR):               run with 'alvr'
- Discord (Snap):           installed
- WiVRn (Flatpak):          io.github.wivrn.wivrn
- Envision (AUR):           run with 'envision'

🛠 System services:
- Avahi:                    enabled for VR device discovery

📁 Source folders:
- Unity:                   "$UNITY_DIR"

🌐 ALCOM Download:
- Opened in browser:       https://vrc-get.anatawa12.com/en/alcom/
-MOVE ALCOM APPIMAAGE TO HOME/PROGRAM FILES

EOF
