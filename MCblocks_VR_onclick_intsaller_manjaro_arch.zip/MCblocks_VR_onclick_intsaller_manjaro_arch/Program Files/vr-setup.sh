#!/bin/bash
set -e

PROGRAMS_DIR="$HOME/Program Files"
UNITY_DIR="$PROGRAMS_DIR/unity"
ALCOM_DIR="$PROGRAMS_DIR/alcom"
WIVRN_DIR="$PROGRAMS_DIR/wivrn"
ENVISION_DIR="$PROGRAMS_DIR/envision"

mkdir -p "$PROGRAMS_DIR"

function install_if_missing() {
  local cmd="$1"
  local pkg="$2"
  if ! command -v "$cmd" &>/dev/null; then
    echo "Installing $pkg..."
    sudo pacman -S --noconfirm "$pkg"
  else
    echo "$pkg already installed."
  fi
}

function install_yay() {
  if ! command -v yay &>/dev/null; then
    echo "yay not found. Installing yay..."
    sudo pacman -S --noconfirm --needed git base-devel
    tmpdir=$(mktemp -d)
    git clone https://aur.archlinux.org/yay.git "$tmpdir/yay"
    pushd "$tmpdir/yay"
    makepkg -si --noconfirm
    popd
    rm -rf "$tmpdir"
    echo "✅ yay installed successfully."
  else
    echo "yay already installed."
  fi
}


function install_snapd() {
  if ! command -v snap &>/dev/null; then
    echo "Installing snapd..."
    sudo pacman -S --noconfirm snapd
    sudo systemctl enable --now snapd.socket
    sudo ln -s /var/lib/snapd/snap /snap || true
    sudo snap install snap-store
  else
    echo "snapd already installed."
  fi
}

function install_snap_app() {
  local appid="$1"
  if ! snap list | grep -q "$appid"; then
    echo "Installing $appid via Snap..."
    sudo snap install "$appid"
  else
    echo "$appid already installed via Snap."
  fi
}

function install_unity_hub() {
  if ! flatpak list | grep -q "com.unity.UnityHub"; then
    echo "Installing Unity Hub via Flatpak..."
    flatpak install -y flathub com.unity.UnityHub
  else
    echo "Unity Hub already installed via Flatpak."
  fi
}

function install_alcom() {
  mkdir -p "$ALCOM_DIR"
  if [ ! -f "$ALCOM_DIR/Alcom.AppImage" ]; then
    echo "Downloading Alcom AppImage..."
    wget -O "$ALCOM_DIR/Alcom.AppImage" https://github.com/abb128/Alcom/releases/download/v0.1.0/Alcom.AppImage || {
      echo "⚠️ Failed to download Alcom. The URL may be out of date. Please check the GitHub releases page.";
      return 1;
    }
    chmod +x "$ALCOM_DIR/Alcom.AppImage"
  else
    echo "Alcom AppImage already exists."
  fi

  echo "Creating Alcom launcher script..."
  cat <<EOF > "$ALCOM_DIR/alcom-launch.sh"
#!/bin/bash
"$ALCOM_DIR/Alcom.AppImage" &
EOF
  chmod +x "$ALCOM_DIR/alcom-launch.sh"
}

function install_wivrn() {
  echo "Installing WiVRn via Flatpak..."
  flatpak install -y flathub io.github.wivrn.wivrn || {
    echo "⚠️ Failed to install WiVRn from Flatpak. You may need to check Flatpak setup or manually install.";
  }
}

function install_envision() {
  echo "Installing Envision via AUR..."
  yay -Sy --noconfirm envision-xr-git || {
    echo "⚠️ Failed to install Envision from AUR. You may need to check AUR availability or install manually.";
  }
}

# Start setup
install_yay

sudo pacman -Syu --noconfirm

# Core tools
install_if_missing steam steam
install_if_missing python python
install_if_missing pip python-pip
install_if_missing mpv mpv
install_if_missing steam steam
install_if_missing git git
install_if_missing blender blender
install_if_missing gimp gimp
install_if_missing xdotool xdotool
install_if_missing wmctrl wmctrl
install_if_missing xwininfo xorg-xwininfo

# Audio tools
install_if_missing pavucontrol pavucontrol
install_if_missing easyeffects easyeffects
install_if_missing helvum helvum
install_if_missing pipewire pipewire
install_if_missing pipewire-pulse pipewire-pulse

# Snap setup
install_snapd

# Discord via Snap
install_snap_app discord

# Optional mpv extensions
yay -Sy --noconfirm mpv-mpris mpv-webm || echo "⚠️ Optional MPV extensions failed."

# ALVR
if yay -Si alvr &>/dev/null; then
  yay -Sy --noconfirm alvr
else
  echo "⚠️ ALVR not found in AUR."
fi

# WiVRn (via Flatpak)
install_wivrn

# Envision (from source)
install_envision

# Unity
install_unity_hub

# Alcom
install_alcom

# Done
cat <<EOF

✅ Setup complete!
➡ Unity Hub: run via Flatpak: flatpak run com.unity.UnityHub
➡ Alcom: $ALCOM_DIR/Alcom.AppImage
➡ Alcom launcher: $ALCOM_DIR/alcom-launch.sh
➡ Run ALVR with: alvr
➡ Run WiVRn: flatpak run io.github.wivrn.wivrn
➡ Run Envision: envision
➡ Use Snap Store or Flatpak for more apps
EOF
